#include "line_search.h"
#include "uart_thread.h"
#include "motor_test.h"


void LINE_SEARCH_Tasks(void){
    //"GET /motor HTTP/1.1\n"
    motorControllerInitialize();
    int state = 0;//idle
    char linedata = '1';
    int right = 0;
    int left = 0;
    initializeUART();
    char lastLine ='1';
    char receive;
    
   
    
    for(;;){
        vTaskDelay(50);
       
        if(state == 0){ //if in idle state            
            if(linedata == '0'){//if not on line
                state = 1;//change to line search
         
            }
            else if(linedata == '1'){
                 transmitUARTstring("{\"line\":\"center\"}");
                 setMotorR(FORWARD,50);
                 setMotorL(FORWARD, 50);
                 lastLine = '1';
            }
            else if (linedata == '2'){
                transmitUARTstring("{\"line\":\"right\"}");
                setMotorL(FORWARD,50);
                setMotorR(REVERSE, 50);
                 lastLine = '2';
            }
            else if(linedata =='3'){
                 transmitUARTstring("{\"line\":\"left\"}");
                 setMotorR(FORWARD,50);
                 setMotorL(REVERSE, 50);
                  lastLine = '3';
            }
          lastLine = linedata;
          linedata = uart_receive();
        }
        else{
            
            if(lastLine = '2'){
                transmitUARTstring("{\"line\":\"lost right\"}");
                setMotorL(FORWARD,50);
                setMotorR(REVERSE, 50);
            }
            else if(lastLine = '3'){
                transmitUARTstring("{\"line\":\"lost left\"}");
                 setMotorR(FORWARD,50);
                 setMotorL(REVERSE, 50);
            }
            
            if(linedata != '0'){//line found
                state = 0; //switch back to idle state
            }
           
        }
        
    }

}