#ifndef _COLOR_QUEUE_H
#define _COLOR_QUEUE_H


#include "FreeRTOS.h"
#include "queue.h"

typedef enum
{
	/* Application's state machine's initial state. */
	COLOR_QUEUE_STATE_INIT=0,

	/* TODO: Define states used by the application state machine. */

} COLOR_QUEUE_STATES;

typedef struct
{
    /* The application's current state */
    COLOR_QUEUE_STATES state;

    /* TODO: Define any additional data used by the application. */


} COLOR_QUEUE_DATA;

struct color_message
    {
        uint32_t red_light;
        uint32_t green_light;
        uint32_t yellow_light;
        
    } yMessage;

void colorSensor_create( void );
void colorSensor_send(int red, int green, int yellow); 
struct color_message * colorSensor_receive( void );
void initializeColorSensor(void);
void COLOR_SENSOR(void);


#endif

