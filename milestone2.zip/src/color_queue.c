

#include "color_queue.h"


#define COLOR_QUEUE_SEND_FREQUENCY_MS         ( 200 / portTICK_PERIOD_MS )
#define COLOR_QUEUE_LENGTH                    ( 1 )

QueueHandle_t cQueue;

void colorSensor_create (void){
	 cQueue = xQueueCreate( 32, sizeof(uint32_t));
}

void colorSensor_send(int red, int green, int yellow){
    struct color_message *partMessage;
    partMessage = & yMessage;
	xQueueSendToBackFromISR( cQueue, ( void * ) &partMessage, (BaseType_t) 0);
}

struct color_message* colorSensor_receive(void){
    struct color_message *myMessage;
	if(xQueueReceive( cQueue, &myMessage, portMAX_DELAY )){
        return myMessage;
    }
}

void initializeColorSensor(void){
    colorSensor_create();
}

void COLOR_SENSOR(void){
    initializeLineSensor();
    struct color_message *COLOR_MESSAGE;
    
    for(;;){
        if(uxQueueMessagesWaiting( cQueue ) > 0){
            COLOR_MESSAGE = colorSensor_receive();
        }
    }
}
/*******************************************************************************
 End of File
 */